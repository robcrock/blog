import { useState } from "react";
import { Background } from "./Background";
import { Data } from "./Data";
      
export default function App() {
  const [data, setData] = useState({
    neutral: 7,
    buy: 22,
    sell: 5,
    strongSell: 1,
    strongBuy: 13,
  });
  return (
    <div>
      <svg viewBox="0 0 100 100" width="450">
        <Background data={data} />
        <Data data={data} />
      </svg>
      <button
        onClick={() => {
          setData({
            neutral: randomBetween(1, 30),
            buy: randomBetween(1, 30),
            sell: randomBetween(1, 30),
            strongSell: randomBetween(1, 30),
            strongBuy: randomBetween(1, 30),
          });
        }}
      >
        Shuffle
      </button>
    </div>
  );
}

function randomBetween(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}