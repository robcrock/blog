import { useRef, useId, useEffect } from "react";
import BezierEasing from "bezier-easing";
import { toPoints, usePrevious } from "./utils";

const ease = BezierEasing(0.25, 0.1, 0.25, 1);

const animate = ({ from, to, duration, onUpdate }) => {
  let startTime = null;
  const animateFrame = (timestamp) => {
    if (!startTime) startTime = timestamp;
    const timeElapsed = timestamp - startTime;
    const progress = ease(Math.min(timeElapsed / duration, 1));
    const x = progress * (to - from) + from;
    onUpdate(x);
    if (progress < 1) {
      requestAnimationFrame(animateFrame);
    }
  };
  requestAnimationFrame(animateFrame);
};

// Update the following component
export function AnimatedLabel({ x, y, name, value }) {
  const previous = usePrevious(value);
  const ref = useRef();

  useEffect(() => {
    animate({
      from: previous,
      to: value,
      duration: 300,
      onUpdate: (v) => {
        if (!ref.current) return;
        ref.current.textContent = `${name} ${v.toFixed(0)}`;
      },
    });
  }, [value]);

  return <text ref={ref} x={x} y={y} />;
}

export function Data({ data }) {
  const animateRef = useRef();
  const previousData = usePrevious(data);
  const id = useId();

  useEffect(() => {
    animateRef.current.beginElement();
  }, [data]);

  return (
    <g>
      <defs>
        <marker id={id} markerWidth="4" markerHeight="4" refX="2" refY="2">
          <circle cx="2" cy="2" r="2" fill="currentColor" />
        </marker>
      </defs>
      <polygon
        points={toPoints(data)}
        stroke="currentColor"
        strokeWidth="0.3"
        fill="#EAEC8A"
        fillOpacity="0.18"
        markerStart={`url(#${id})`}
        markerMid={`url(#${id})`}
      >
        <animate
          ref={animateRef}
          attributeName="points"
          from={toPoints(previousData)}
          to={toPoints(data)}
          dur="0.3s"
          fill="freeze"
          begin="indefinite"
          calcMode="spline"
          keyTimes="0; 1"
          keySplines="0.25 0.1 0.25 1"
        />
      </polygon>
    </g>
  );
}
