export function CurrentTime({ time }) {
  return <p className="timer-text">{formatTime(time)}</p>;
}

const formatTime = (seconds) => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${String(remainingSeconds).padStart(2, "0")}`;
};
