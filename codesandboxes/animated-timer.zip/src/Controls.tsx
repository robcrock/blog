export function Controls({ timeLeft, isRunning, onTimeChange, onPlay }) {
  return (
    <div className="controls">
      <button
        disabled={isRunning}
        onClick={() => {
          const nextTime = Math.max(0, timeLeft - 10);
          onTimeChange(nextTime);
        }}
      >
        -
      </button>
      <button id="play" disabled={isRunning} onClick={onPlay}>
        Play
      </button>
      <button
        disabled={isRunning}
        onClick={() => {
          const nextTime = timeLeft + 10;
          onTimeChange(nextTime);
        }}
      >
        +
      </button>
    </div>
  );
}
