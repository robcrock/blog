import React from 'react';

import LikeButton from './LikeButton';

export default function App() {
  const [isLiked, setIsLiked] = React.useState(false);
  
  return (
    <div className="app">
      <LikeButton
        isLiked={isLiked}
        handleToggle={(newValue) => {
          // Optimistically the local state variable:
          setIsLiked(newValue);
          
          // Update the “like” status in the database:
          // eg. fetch('/api/like-post')
        }}
      />
    </div>
  )
}