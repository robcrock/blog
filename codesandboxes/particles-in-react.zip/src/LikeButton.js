import React from 'react';

import VisuallyHidden from './VisuallyHidden';
import {
  PARTICLE_DELAY,
  generateParticles,
  useCleanup,
} from './LikeButton.helpers';
import './LikeButton.css';

function LikeButton({ isLiked, handleToggle, numOfParticles = 20 }) {
  const [particles, setParticles] = React.useState([]);

  // To dispose of faded-out particles, I’m using a custom hook.
  // You can see how I’m doing this in “LikeButton.helpers.js”.
  useCleanup(isLiked, setParticles);

  return (
    <button
      className={isLiked ? 'particleButton liked' : 'particleButton'}
      style={{
        '--pop-circle-duration': PARTICLE_DELAY + 'ms',
      }}
      onClick={() => {
        handleToggle(!isLiked);
        
        if (isLiked) {
          return;
        }
        
        // Add a short delay before generating the particles,
        // so that they appear after the popping circle has popped.
        window.setTimeout(() => {
          // Create new particles and merge them in with our
          // existing particles. This ensures that if the user
          // clicks multiple times quickly, older particles don’t
          // prematurely blink out of existence.
          setParticles([
            ...particles,
            ...generateParticles(numOfParticles),
          ]);
        }, PARTICLE_DELAY);
      }}
    >
      {particles.map((particle) => (
        <span
          // In React, keys are needed to help React optimize
          // the DOM operations when the particles change.
          key={particle.id}
          className="particle"
          style={{
            '--angle': particle.angle + 'deg',
            '--distance': particle.distance + 'px',
            '--size': particle.size + 'px',
            '--fade-duration': particle.fadeDuration + 'ms',
            '--fade-delay': particle.fadeDelay + 'ms',
            '--pop-duration': particle.popDuration + 'ms',
            '--color': particle.color,
            '--hue-rotation': particle.hueRotation + 'deg',
            '--twinkle-amount': particle.twinkleAmount,
            '--twinkle-duration': particle.twinkleDuration + 'ms',
          }}
        />
      ))}
      
      {/*
        Conditionally render the pop circle based on the “isLiked”
        prop. In React, it’s more conventional to do this sort of
        thing, rather than applying CSS conditionally, like we
        were in the vanilla JS version.
      */}
      {isLiked && <span className="popCircle" />}
      
      <svg
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <path
          d="M3.68546 5.43796C8.61936 1.29159 11.8685 7.4309 12.0406 7.4309C12.2126 7.43091 15.4617 1.29159 20.3956 5.43796C26.8941 10.8991 13.5 21.8215 12.0406 21.8215C10.5811 21.8215 -2.81297 10.8991 3.68546 5.43796Z"
        />
      </svg>
      
      <VisuallyHidden>Like this post</VisuallyHidden>
    </button>
  );
}

export default LikeButton;