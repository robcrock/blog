import React from 'react';
import { random, range } from 'lodash';

import { normalize } from './utils';

export const MIN_DISTANCE = 32;
export const MAX_DISTANCE = 64;
export const MIN_FADE_DURATION = 1000 - 500;
export const MAX_FADE_DURATION = 1000 + 500;
export const MAX_FADE_DELAY = 500;
export const MAX_FADE_ADJUST = 200;
export const PARTICLE_DELAY = 150;

export const MAX_PARTICLE_AGE =
  MAX_FADE_DURATION + MAX_FADE_DELAY + MAX_FADE_ADJUST + PARTICLE_DELAY;

export function generateParticles(numOfParticles) {
  return range(numOfParticles).map((index) => {
    let angle = normalize(index, 0, numOfParticles, 0, 360);
    angle += random(-40, 40);

    const distance = random(MIN_DISTANCE, MAX_DISTANCE);

    return {
      // “crypto.randomUUID()” is a utility built into the
      // browser that will generate a guaranteed-unique ID.
      // It has nothing to do with cryptocurrency. 😅
      // The “id” is used exclusively for the “key” prop.
      id: crypto.randomUUID(),
      
      // Everything else is the same as our vanilla JS version:
      angle,
      distance,
      color: `hsl(${random(0, 360)} 90% 85%)`,
      hueRotation: random(180, 720),
      fadeDuration:
        normalize(
          distance,
          MIN_DISTANCE,
          MAX_DISTANCE,
          MIN_FADE_DURATION,
          MAX_FADE_DURATION
        ) + random(-200, 200),
      fadeDelay:
        normalize(
          distance,
          MIN_DISTANCE,
          MAX_DISTANCE,
          0,
          MAX_FADE_DELAY
        ) + random(0, MAX_FADE_ADJUST),
      popDuration:
        normalize(distance, MIN_DISTANCE, MAX_DISTANCE, 400, 800) +
        random(-200, 200),
      size: random(9, 15),
      twinkleDuration: random(150, 300),
      twinkleAmount: random(0.325, 1, true),
    };
  });
}

export function useCleanup(isLiked, setParticles) {
  // This effect runs whenever the user toggles the “isLiked”
  // status by clicking the button. It schedules a timeout to
  // delete particles that have finished fading away.
  React.useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      setParticles([]);
    }, MAX_PARTICLE_AGE + 200);

    // This returned function will get called right before
    // running the effect. This will cancel the timeout if
    // the user toggles the button again before the particles
    // have finished fading away, guaranteeing that we never
    // erase particles that are mid-fade.
    // You can think of this whole thing as a debounce. The
    // timeout only fires when “isLiked” hasn’t changed for
    // a few seconds.
    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [isLiked, setParticles]);
}